from ase.io import read,write
import ase.db
import random
from ase import Atoms,Atom
import numpy as np
import matplotlib.pyplot as plt


Ratio = [8,16,24,32,40,48,56]
Activity = []
Fill_down = []
Fill_up = []
for Gene in ['init/','g1/','g2/','g3/','g4/','g5/']:
    Activity_gene = []
    Sigma_gene = []
    for ratio in Ratio:
        ei_0 = np.loadtxt(Gene+str(ratio)+'/0/Fitness_max_global.csv',delimiter=',')[-1]
        ei_1 = np.loadtxt(Gene+str(ratio)+'/1/Fitness_max_global.csv',delimiter=',')[-1]
        ei_2 = np.loadtxt(Gene+str(ratio)+'/2/Fitness_max_global.csv',delimiter=',')[-1]
        ei_max = max([ei_0, ei_1, ei_2])
        ei_max_index = [ei_0, ei_1, ei_2].index(ei_max)
        activity_max_global = np.loadtxt(Gene+str(ratio)+'/'+str(ei_max_index)+'/Activity_fitness_max.csv', delimiter=',', encoding="UTF-8-sig")[-1]
        sigma_max_global = np.loadtxt(Gene+str(ratio)+'/'+str(ei_max_index)+'/Sigma_fitness_max.csv', delimiter=',', encoding="UTF-8-sig")[-1]
        
        Activity_gene.append(activity_max_global)
        Sigma_gene.append(sigma_max_global)
    fill_down_gene = [Activity_gene[i]-Sigma_gene[i] for i in range(len(Activity_gene))]
    fill_up_gene = [Activity_gene[i]+Sigma_gene[i] for i in range(len(Activity_gene))]
    Activity.append(Activity_gene)
    Fill_down.append(fill_down_gene)
    Fill_up.append(fill_up_gene)

Colors = ['#264653','#2A9D8F','#E9C46A','#F4A261','#E76F51','#E63946']
Ratio = [i/64*100 for i in Ratio]
# 一张图
# fig, ax = plt.subplots(figsize=(5,4))
# # 设置刻度线朝内
# ax.tick_params(which='both', direction='in', top=False, right=False)
# # 设置次刻度线的样式
# ax.tick_params(which='minor', length=3,)  # 你可以调整颜色和长度
# ax.tick_params(which='major', length=6,)  # 你可以调整颜色和长度

# plt.ylim([-1.25,0.2])
# plt.xlim([5,95])
# plt.rc('font',family='Arial')
# plt.rcParams['xtick.direction']='in'
# plt.rcParams['ytick.direction']='in'

# plt.plot(Ratio,Activity[0],'-o',color=Colors[0])
# plt.plot(Ratio,Activity[1],'-o',color=Colors[1])
# plt.plot(Ratio,Activity[2],'-o',color=Colors[2])
# plt.plot(Ratio,Activity[3],'-o',color=Colors[3])
# plt.plot(Ratio,Activity[4],'-o',color=Colors[4])
# plt.plot(Ratio,Activity[5],'-o',color=Colors[5])
# plt.legend(['g1','g2','g3','g4','g5','g6'],ncol=2,loc=3,frameon=False)
# plt.fill_between(Ratio, Fill_down[0], Fill_up[0], facecolor=Colors[0], alpha=0.5)
# plt.fill_between(Ratio, Fill_down[1], Fill_up[1], facecolor=Colors[1], alpha=0.5)
# plt.fill_between(Ratio, Fill_down[2], Fill_up[2], facecolor=Colors[2], alpha=0.5)
# plt.fill_between(Ratio, Fill_down[3], Fill_up[3], facecolor=Colors[3], alpha=0.5)
# plt.fill_between(Ratio, Fill_down[4], Fill_up[4], facecolor=Colors[4], alpha=0.5)
# plt.fill_between(Ratio, Fill_down[5], Fill_up[5], facecolor=Colors[5], alpha=0.5)
# plt.tick_params(labelsize=14)
# plt.xlabel('Ni ratio (%)',fontsize=16)
# plt.ylabel('ORR activity (%)',fontsize=16)
# plt.savefig('u-sigma-all.eps',bbox_inches='tight')





# 子图
fig, ((ax1, ax2, ax3), (ax4, ax5, ax6)) = plt.subplots(2, 3, figsize=(12, 6))

ax1.plot(Ratio,Activity[0],'-o',color=Colors[0])
ax1.fill_between(Ratio, Fill_down[0], Fill_up[0], facecolor=Colors[0], alpha=0.5)
ax1.set_ylim([-1.0,0.25])
ax1.tick_params(direction='in',labelsize=14,which='major', length=6,)
ax1.legend(['g1'],frameon=False,fontsize=16)

ax2.plot(Ratio,Activity[1],'-o',color=Colors[1])
ax2.fill_between(Ratio, Fill_down[1], Fill_up[1], facecolor=Colors[1], alpha=0.5)
ax2.set_ylim([-1.0,0.25])
ax2.tick_params(direction='in',labelsize=14,which='major', length=6,labelleft=False)
ax2.legend(['g2'],frameon=False,fontsize=16)

ax3.plot(Ratio,Activity[2],'-o',color=Colors[2])
ax3.fill_between(Ratio, Fill_down[2], Fill_up[2], facecolor=Colors[2], alpha=0.5)
ax3.set_ylim([-1.0,0.25])
ax3.tick_params(direction='in',labelsize=14,which='major', length=6,labelleft=False)
ax3.legend(['g3'],frameon=False,fontsize=16)

ax4.plot(Ratio,Activity[3],'-o',color=Colors[3])
ax4.fill_between(Ratio, Fill_down[3], Fill_up[3], facecolor=Colors[3], alpha=0.5)
ax4.set_ylim([-1.0,0.25])
ax4.tick_params(direction='in',labelsize=14,which='major', length=6)
ax4.legend(['g4'],frameon=False,fontsize=16)

ax5.plot(Ratio,Activity[4],'-o',color=Colors[4])
ax5.fill_between(Ratio, Fill_down[4], Fill_up[4], facecolor=Colors[4], alpha=0.5)
ax5.set_ylim([-1.0,0.25])
ax5.tick_params(direction='in',labelsize=14,which='major', length=6,labelleft=False)
ax5.legend(['g5'],frameon=False,fontsize=16)

ax6.plot(Ratio,Activity[5],'-o',color=Colors[5])
ax6.fill_between(Ratio, Fill_down[5], Fill_up[5], facecolor=Colors[5], alpha=0.5)
ax6.set_ylim([-1.0,0.25])
ax6.tick_params(direction='in',labelsize=14,which='major', length=6,labelleft=False)
ax6.legend(['g6'],frameon=False,fontsize=16)

plt.subplots_adjust(wspace=0.1) 
plt.savefig('u-sigma-sep.eps',bbox_inches='tight')
# 显示图形
plt.show()
