from ase.io import read,write
import ase.db
import random
from ase import Atoms,Atom
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

# Create a formatter function
formatter = FuncFormatter(lambda x, _: f'{x:.2f}')
Ratio = [i for i in range(1,64)]
EI = []
for ratio in Ratio:
    ei_0 = np.loadtxt(str(ratio)+'/0/Fitness_max_global.csv',delimiter=',')[-1]
    ei_1 = np.loadtxt(str(ratio)+'/1/Fitness_max_global.csv',delimiter=',')[-1]
    ei_2 = np.loadtxt(str(ratio)+'/2/Fitness_max_global.csv',delimiter=',')[-1]
    ei_max = max([ei_0, ei_1, ei_2])
    EI.append(ei_max)

ratio_ei_max = Ratio[EI.index(max(EI))]
print('max_ei in', ratio_ei_max)

LEN = [8,16,24,32,40,48,56]
Fitness_current = []
Fitness_gloabl = []
for Len in LEN:
    p = read('pure.traj') 
    ei_0 = np.loadtxt(str(ratio)+'/0/Fitness_max_global.csv',delimiter=',')[-1]
    ei_1 = np.loadtxt(str(ratio)+'/1/Fitness_max_global.csv',delimiter=',')[-1]
    ei_2 = np.loadtxt(str(ratio)+'/2/Fitness_max_global.csv',delimiter=',')[-1]
    ei_max = np.where(ei_0, ei_1, ei_2)
    ei_max_index = [ei_0, ei_1, ei_2].index(ei_max)
    gene = np.loadtxt(str(Len)+'/'+str(ei_max_index)+'/Gene_fitness_max_global.csv',delimiter=',')
    fitness_current = np.loadtxt(str(Len)+'/'+str(ei_max_index)+'/Fitness_max_current.csv',delimiter=',')
    fitness_global = np.loadtxt(str(Len)+'/'+str(ei_max_index)+'/Fitness_max_global.csv',delimiter=',')
    Fitness_current.append(fitness_current)
    Fitness_gloabl.append(fitness_global)

fig, axs = plt.subplots(2, 4, figsize=(12, 6))
# 绘制每个子图，手动指定每个子图的位置
axs[0, 0].plot(Fitness_current[0])
axs[0, 0].plot(Fitness_gloabl[0])
axs[0, 0].set_title(r'$\rm Pt_{56}Ni_8$')
axs[0, 0].legend(['Fitness','Fitness_max'],frameon=False,loc=4)
axs[0, 0].yaxis.set_major_formatter(formatter)

axs[0, 1].plot(Fitness_current[1])
axs[0, 1].plot(Fitness_gloabl[1])
axs[0, 1].set_title(r'$\rm Pt_{48}Ni_{16}$')
axs[0, 1].legend(['Fitness','Fitness_max'],frameon=False,loc=4)
axs[0, 1].yaxis.set_major_formatter(formatter)

axs[0, 2].plot(Fitness_current[2])
axs[0, 2].plot(Fitness_gloabl[2])
axs[0, 2].set_title(r'$\rm Pt_{40}Ni_{24}$')
axs[0, 2].legend(['Fitness','Fitness_max'],frameon=False,loc=4)
axs[0, 2].yaxis.set_major_formatter(formatter)

axs[0, 3].plot(Fitness_current[3])
axs[0, 3].plot(Fitness_gloabl[3])
axs[0, 3].set_title(r'$\rm Pt_{32}Ni_{32}$')
axs[0, 3].legend(['Fitness','Fitness_max'],frameon=False,loc=4)
axs[0, 3].yaxis.set_major_formatter(formatter)

axs[1, 0].plot(Fitness_current[4])
axs[1, 0].plot(Fitness_gloabl[4])
axs[1, 0].set_title(r'$\rm Pt_{24}Ni_{40}$')
axs[1, 0].legend(['Fitness','Fitness_max'],frameon=False,loc=4)
axs[1, 0].yaxis.set_major_formatter(formatter)

axs[1, 1].plot(Fitness_current[5])
axs[1, 1].plot(Fitness_gloabl[5])
axs[1, 1].set_title(r'$\rm Pt_{16}Ni_{48}$')
axs[1, 1].legend(['Fitness','Fitness_max'],frameon=False,loc=4)
axs[1, 1].yaxis.set_major_formatter(formatter)

axs[1, 2].plot(Fitness_current[6])
axs[1, 2].plot(Fitness_gloabl[6])
axs[1, 2].set_title(r'$\rm Pt_{8}Ni_{56}$')
axs[1, 2].legend(['Fitness','Fitness_max'],frameon=False,loc=4)
axs[1, 2].yaxis.set_major_formatter(formatter)

# 调整布局以防止标题和标签重叠
plt.tight_layout()
plt.savefig('ga.eps',bbox_inches='tight')

# 显示图形
plt.show()
