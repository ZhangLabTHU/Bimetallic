# copyright THU-Zhanglab
# coding:utf-8 

import random
from operator import itemgetter
import numpy as np
from ase.io import read
from ase.neighborlist import NeighborList
import pickle
from random import sample
from scipy.stats import norm
import os
import warnings
warnings.filterwarnings("ignore")

# extract neighborlist based on pure.traj
atoms = read('pure.traj')
radius = [1.5]*64 # set 1.5 to make sure surf atoms have 10 neighbors and bulk atoms have 14 neighbors.  
nl = NeighborList(radius, self_interaction=False, bothways=True)
nl.update(atoms)
# neighbor store the neighbor atoms index in PdAu.
neighbor_list = {}
coordination_list = {}
adsorption_list = {}
for index in range(len(atoms)):
    indices, offsets = nl.get_neighbors(index)
    indices = indices.tolist()
    neighbor_list[index] = indices 
    coordination_list[index] = len(indices)

# extract adsorptionlist based on pure.traj
# adsorption_list保存每一个位点对应的三层shell
adsorption_coordination_list = {} #按照配位数划分

# 读取pure.traj，扩展3倍
atoms = read('pure.traj') 
extend_atoms = atoms*[3,3,1]

# fcc_indices记录扩胞后16个组成fcc位点的3个原子标号
fcc_indices = [[268,270,269],[270,300,271],[300,302,301],[302,460,303],
              [269,271,284],[271,301,286],[301,303,316],[303,461,318],
              [284,286,285],[286,316,287],[316,318,317],[318,319,476],
              [285,287,332],[287,317,334],[317,319,364],[319,477,366]]

# 通过近邻判断原子数
radius = [1.5]*576 # set 1.5 to make sure surf atoms have 10 neighbors and bulk atoms have 14 neighbors.  
nl = NeighborList(radius, self_interaction=False, bothways=True)
nl.update(extend_atoms)
neighbor_extend_list = {}
coordination_extend_list ={}
for index in range(len(extend_atoms)):
    indices, offsets = nl.get_neighbors(index)
    indices = indices.tolist()
    neighbor_extend_list[index] = indices
    coordination_extend_list[index] = len(indices)

# 每一个fcc位点划分6层特征，6层原子数分别为3，3，3，6，3，40
for num in range(16):
    first_shell = fcc_indices[num]
    
    second_shell = []
    for i in first_shell:
        neighbor_i = neighbor_extend_list[i]
        for j in neighbor_i:
            if j not in first_shell and j not in second_shell:
                second_shell.append(j)
    
    third_shell = []
    for i in second_shell:
        neighbor_i = neighbor_extend_list[i]
        for j in neighbor_i:
            if j not in second_shell and j not in third_shell:
                third_shell.append(j)
    
    position1 = extend_atoms[first_shell[0]].position+[0,0,1.2]
    position2 = extend_atoms[first_shell[1]].position+[0,0,1.2]
    position3 = extend_atoms[first_shell[2]].position+[0,0,1.2]
    center_position = (position1+position2+position3)/3
    second_shell_distance = {}
    for index in second_shell:
        second_shell_distance[index] = np.linalg.norm(center_position-extend_atoms[index].position)
    second_shell_distance_ordered = sorted(second_shell_distance.items(), key=lambda item:item[1])
    second_shell_distance_sub1 = [second_shell_distance_ordered[i][0] for i in range(0,3)] 
    second_shell_distance_sub2 = [second_shell_distance_ordered[i][0] for i in range(3,6)]
    second_shell_distance_sub3 = [second_shell_distance_ordered[i][0] for i in range(6,12)]
    second_shell_distance_sub4 = [second_shell_distance_ordered[i][0] for i in range(12,15)]
    
    adsorption_shell = []
    adsorption_shell.append([i%64 for i in first_shell])
    adsorption_shell.append([i%64 for i in second_shell_distance_sub1])
    adsorption_shell.append([i%64 for i in second_shell_distance_sub2])
    adsorption_shell.append([i%64 for i in second_shell_distance_sub3])
    adsorption_shell.append([i%64 for i in second_shell_distance_sub4])
    adsorption_coordination_list[num] = adsorption_shell

neighbor_multi_list = []
for i in range(5*64,6*64):
    neigh_i_dict = {}
    first_shell_i = neighbor_extend_list[i].copy()
    total_shell_i = first_shell_i.copy()
    
    second_shell_i = []
    for j in first_shell_i:
        shell_ij = neighbor_extend_list[j].copy()
        for k in shell_ij:
            if (k not in total_shell_i) and (k not in second_shell_i):
                second_shell_i.append(k)
                total_shell_i.append(k)
            elif k not in total_shell_i:
                total_shell_i.append(k)
    
    third_shell_i = []
    for j in second_shell_i:
        shell_ij = neighbor_extend_list[j].copy()
        for k in shell_ij:
            if (k not in total_shell_i) and (k not in third_shell_i):
                third_shell_i.append(k)
                total_shell_i.append(k)
            elif k not in total_shell_i:
                total_shell_i.append(k)

    fourth_shell_i = []
    for j in third_shell_i:
        shell_ij = neighbor_extend_list[j].copy()
        for k in shell_ij:
            if (k not in total_shell_i) and (k not in fourth_shell_i):
                fourth_shell_i.append(k)
                total_shell_i.append(k)
            elif k not in total_shell_i:
                total_shell_i.append(k)
    
    fifth_shell_i = []
    for j in fourth_shell_i:
        shell_ij = neighbor_extend_list[j].copy()
        for k in shell_ij:
            if (k not in total_shell_i) and (k not in fifth_shell_i):
                fifth_shell_i.append(k)
                total_shell_i.append(k)
            elif k not in total_shell_i:
                total_shell_i.append(k)
    
    neigh_i_dict[1] = [i%64 for i in first_shell_i.copy()]
    #print('first shell:',len(first_shell_i))
    neigh_i_dict[2] = [i%64 for i in second_shell_i.copy()]
    #print('second shell:',len(second_shell_i))
    neigh_i_dict[3] = [i%64 for i in third_shell_i.copy()]
    #print('third shell:',len(third_shell_i))
    neigh_i_dict[4] = [i%64 for i in fourth_shell_i.copy()]
    #print('fourth shell:',len(fourth_shell_i))
    neigh_i_dict[5] = [i%64 for i in fifth_shell_i.copy()]
    neighbor_multi_list.append(neigh_i_dict)

def add_to_list(list_target, shell_pd, shell_coord_pd, shell_au, shell_coord_au):
    if len(shell_pd) !=0:
        list_target.append(len(shell_pd))
        list_target.append(np.mean(shell_coord_pd))
    else:
        list_target.append(0)
        list_target.append(0)

    if len(shell_au) !=0:
        list_target.append(len(shell_au))   # number  
        list_target.append(np.mean(shell_coord_au)) # mean of coordination number 

    else:
        list_target.append(0)
        list_target.append(0)
        
    return list_target


def feature_from_config_int(config_int):
    Feature = []
    au_atom_list = [i for i,x in enumerate(config_int) if x==1]
    ratio = len(au_atom_list)/len(config_int)
    for i in range(16):
        adsorption_coordination_feature = []
        for j in range(5):
            shell = adsorption_coordination_list[i][j]
            shell_pd = [k for k in shell if k not in au_atom_list]
            shell_pd_coord = [coordination_list[k] for k in shell_pd]
            shell_au = [k for k in shell if k in au_atom_list]
            shell_au_coord = [coordination_list[k] for k in shell_au]
            adsorption_coordination_feature = add_to_list(adsorption_coordination_feature, shell_pd, shell_pd_coord, shell_au, shell_au_coord)
        Feature.append(adsorption_coordination_feature + [ratio])
    return Feature

def evaluate(geneinfo):
    """
    fitness function
    """
    # translate the chromosome to the structure code
    config_int = []
    for i in range(64):
        if i in geneinfo:
            config_int.append(1)
        else:
            config_int.append(0)
    feature = feature_from_config_int(config_int)
    preprocessing = pickle.load(open("Preprocessing.pkl", "rb"))
    model = pickle.load(open("GPRmodel.model", "rb"))
    # Predict the adsorption energy by ML model
    feature = preprocessing.transform(feature)
    ads_energy_predict, sigma_predict = model.predict(feature,return_std=True)
    Activity = [0.6*(eo+0.23)-1.376 if eo < 1.58 else -1.645*(eo+0.23)+2.688 for eo in ads_energy_predict]    
    # u:average activity of 16 fcc sites on PtNi surface
    kT = 0.025852
    Current = [pow(10, a/kT) for a in Activity]
    return np.mean(Current)

for i in range(1,64):
    for num in ['/0/','/1/','/2/']:
        path = str(i) + num 
        gene = np.loadtxt(path+'Gene_fitness_max_global.csv', delimiter=',')
        current = evaluate(gene)
        np.savetxt(path+'/Current_fitness_max_global.csv',[current])
