from camkit.sampling.sitesfinder import SitesFinder
from ase.io import read,write
import ase.db
import random
from ase import Atoms,Atom
import numpy as np
db=ase.db.connect('ptni_g4.db')

Ratio = [i for i in range(1,64)]
EI = []
for ratio in Ratio:
    ei_0 = np.loadtxt(str(ratio)+'/0/Fitness_max_global.csv',delimiter=',')[-1]
    ei_1 = np.loadtxt(str(ratio)+'/1/Fitness_max_global.csv',delimiter=',')[-1]
    ei_2 = np.loadtxt(str(ratio)+'/2/Fitness_max_global.csv',delimiter=',')[-1]
    ei_max = max(ei_0, ei_1, ei_2)
    EI.append(ei_max)

ratio_ei_max = Ratio[EI.index(max(EI))]
print('max_ei in', ratio_ei_max)

LEN = [8,16,24,32,40,48,56, ratio_ei_max]
for Len in LEN:
    p = read('pure.traj') 
    ei_0 = np.loadtxt(str(ratio)+'/0/Fitness_max_global.csv',delimiter=',')[-1]
    ei_1 = np.loadtxt(str(ratio)+'/1/Fitness_max_global.csv',delimiter=',')[-1]
    ei_2 = np.loadtxt(str(ratio)+'/2/Fitness_max_global.csv',delimiter=',')[-1]
    ei_max = max(ei_0, ei_1, ei_2)
    ei_max_index = [ei_0, ei_1, ei_2].index(ei_max)
    gene = np.loadtxt(str(Len)+'/'+str(ei_max_index)+'/Gene_fitness_max_global.csv',delimiter=',')
    if Len ==1:
        gene = [gene]
    symbols = []
    for i in range(64):
        if i in gene:
            symbols.append('Ni')
        else:
            symbols.append('Pt')
    p.set_chemical_symbols(symbols)

    alpha = [-0.113929,-0.113929,-0.035835]
    r=len(gene)/64
    strain = [alpha[j] * r for j in range(3)]
    scaled_cell = [p.get_cell()[i] * (1. + strain[i]) for i in range(3)] 
    p.set_cell(scaled_cell, scale_atoms=True)

    ads = SitesFinder(p,length=1.2,pbc=[1,1,0])
    sites_fcc=ads.find_sites()['fcc']

    def get_unique_id(ads_numbers, key, gene):
        guest_code = format(28, '03d') # Ni元素原子序数
        ads_code = ''   # 吸附原子编号和被吸附原子编号
        for number in ads_numbers:
            ads_code += format(number, '03d')
        for ki in key:
            ads_code += format(int(ki), '03d')
        config_code = '' # 结构信息，二进制-十六进制
        
        temp_list = []
        for i in range(64):
            if i in gene:
                temp_list.append(1)
            else:
                temp_list.append(0)
        for ti in temp_list:
            config_code += str(ti)
        config_code = hex(int(config_code, 2))
        unique_code = guest_code + config_code + ads_code
        return unique_code

    # create sur
    uid = get_unique_id([0], [], gene)
    sid = get_unique_id([0], [], gene)
    if db.count('sid='+sid)==0:
        db.write(p, status='unrelaxed', jobtype='sur', uid=uid, sid=sid)

        # create ads
        n_config = 3
        if len(sites_fcc) < n_config:
            n_config = len(sites_fcc)
        sites_random = random.sample(sites_fcc.keys(), n_config)
        for key in sites_random:
            print(sites_fcc[key])
            mol = Atom('O', position=np.array(sites_fcc[key]))
            ads_config = p.copy()
            ads_config += mol
            uid = get_unique_id([64], key, gene)
            sid = get_unique_id([0], [], gene)
            db.write(ads_config, status='unrelaxed', jobtype='ads', uid=uid, sid=sid)
            del ads_config