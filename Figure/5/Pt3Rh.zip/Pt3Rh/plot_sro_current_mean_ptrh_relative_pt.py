from ase.io import read,write
import ase.db
import random
from ase import Atoms,Atom
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

Colors = [[0.94, 0.56, 0.62],[0.68,0.43,0.81],[0.00, 0.41, 0.52],[0.33, 0.56, 0.75],[1.00, 0.82, 0.13],]
SRO = np.loadtxt('Pt3Rh/sro.csv',delimiter=',')
Activity = np.loadtxt('Pt3Rh/current.csv',delimiter=',')
log_current_pt =  0.6*(1.37+0.23)-1.376
kT = 0.025852
current_pt = pow(10, log_current_pt/kT)

Activity = [ (i/current_pt)  for i in Activity]
data = pd.DataFrame({'sro':SRO, 'activity':Activity})
average_data_pt3ag = data.groupby('sro')['activity'].agg(['mean']).reset_index()
print(average_data_pt3ag)

fig, ax = plt.subplots(figsize=(4.5,4))
# 设置刻度线朝内
ax.tick_params(which='both', direction='in', top=False, right=False)
# 设置次刻度线的样式
ax.tick_params(direction='in',labelsize=12, which='major', length=6,)  # 你可以调整颜色和长度
plt.plot(average_data_pt3ag['sro'].to_numpy(), average_data_pt3ag['mean'].to_numpy(), 
             marker='o',markersize=12,markerfacecolor='w',markeredgecolor=Colors[1],color=Colors[1])
ax.set_yscale('log')
ax.set_ylim([1e-15,1e5])
ax.set_yticks([1e-15,1e-10,1e-5,1e0,1e5])

ax.set_xlabel(r'$\rm \alpha^{Pt-Au}$',fontsize=14)
ax.set_ylabel('Mean ORR activity',fontsize=14)
plt.savefig('sro_mean_current_ptrh_relative_pt.eps',bbox_inches='tight')
# 显示图形
plt.show()