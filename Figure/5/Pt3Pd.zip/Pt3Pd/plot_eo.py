import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

# 导入数据，并每隔50个样本取样
Site = np.loadtxt('feature.csv', delimiter=',')[:, 0][::10]
Eo = np.loadtxt('eo.csv', delimiter=',')[::10]
Eo = [i - 1.37 for i in Eo]

# 创建DataFrame
data = pd.DataFrame({'site': Site, 'eo': Eo})

# 提取不同站点的能量数据
Energy_Pt3 = data.loc[data['site'] == 3, 'eo'].to_numpy()
Energy_Pt2M = data.loc[data['site'] == 2, 'eo'].to_numpy()
Energy_PtM2 = data.loc[data['site'] == 1, 'eo'].to_numpy()
Energy_M3 = data.loc[data['site'] == 0, 'eo'].to_numpy()

# 将不同站点的能量数据合并为一个 DataFrame 方便绘图
combined_data = pd.DataFrame({
    'Energy': np.concatenate([Energy_Pt3, Energy_Pt2M, Energy_PtM2, Energy_M3]),
    'Site': ['Pt3'] * len(Energy_Pt3) + ['Pt2M'] * len(Energy_Pt2M) + ['PtM2'] * len(Energy_PtM2) + ['M3'] * len(Energy_M3)
})

# 绘制小提琴图
plt.figure(figsize=(4.5, 4))
plt.axhline(y=0.2, color='gray', linestyle='--', linewidth=2)
sns.violinplot(x='Site', y='Energy', data=combined_data, palette="Set2", width=1.2)


# 设置刻度线朝内
plt.tick_params(axis='both', direction='in', length=6)

# 设置字体为 Arial，大小为 12
plt.ylim([-0.5,0.5])
plt.xticks(fontsize=12, fontname='Arial')
plt.yticks(fontsize=12, fontname='Arial')

# 设置标题和标签
plt.title('Energy Distribution by Site', fontsize=14, fontname='Arial')
plt.xlabel('Site', fontsize=12, fontname='Arial')
plt.ylabel('Energy', fontsize=12, fontname='Arial')

# 自动调整布局
plt.tight_layout()
plt.savefig('eo_site.eps',bbox_inches='tight')

# 显示图形
plt.show()
