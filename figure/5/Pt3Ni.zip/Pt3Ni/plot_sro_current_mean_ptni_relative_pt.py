from ase.io import read,write
import ase.db
import random
from ase import Atoms,Atom
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

SRO = np.loadtxt('PtNi/sro.csv',delimiter=',')
Activity = np.loadtxt('PtNi/current.csv',delimiter=',')
log_current_pt =  0.6*(1.37+0.23)-1.376
kT = 0.025852
current_pt = pow(10, log_current_pt/kT)

Activity = [ (i/current_pt)  for i in Activity]
data = pd.DataFrame({'sro':SRO, 'activity':Activity})
average_data_pt3ag = data.groupby('sro')['activity'].agg(['mean']).reset_index()
print(average_data_pt3ag)

fig, ax = plt.subplots(figsize=(4.5,4))
# 设置刻度线朝内
ax.tick_params(which='both', direction='in', top=False, right=False)
# 设置次刻度线的样式
ax.tick_params(direction='in',labelsize=12, which='major', length=6,)  # 你可以调整颜色和长度
plt.plot(average_data_pt3ag['sro'].to_numpy(), average_data_pt3ag['mean'].to_numpy(), 
             marker='o',markersize=12,markerfacecolor='w',markeredgecolor='#2ca02c',color='#2ca02c')
ax.set_yscale('log')
ax.set_ylim([1e-20,1e5])
ax.set_xlabel(r'$\rm \alpha^{Pt-Ni}$',fontsize=14)
ax.set_ylabel('Mean ORR activity',fontsize=14)
plt.savefig('sro_mean_current_ptni_relative_pt.eps',bbox_inches='tight')
# 显示图形
plt.show()