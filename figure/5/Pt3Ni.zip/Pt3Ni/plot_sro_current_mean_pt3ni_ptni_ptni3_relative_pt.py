import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

log_current_pt =  0.6*(1.37+0.23)-1.376
kT = 0.025852
current_pt = pow(10, log_current_pt/kT)

SRO_pt3ni = np.loadtxt('Pt3Ni/sro.csv',delimiter=',')
Activity_pt3ni = np.loadtxt('Pt3Ni/current.csv',delimiter=',')
Activity_pt3ni = [ (i/current_pt)  for i in Activity_pt3ni]
data_pt3ni = pd.DataFrame({'sro':SRO_pt3ni, 'activity':Activity_pt3ni})
average_data_pt3ni = data_pt3ni.groupby('sro')['activity'].agg(['mean']).reset_index()

SRO_ptni = np.loadtxt('PtNi/sro.csv',delimiter=',')
Activity_ptni = np.loadtxt('PtNi/current.csv',delimiter=',')
Activity_ptni = [ (i/current_pt)  for i in Activity_ptni]
data_ptni = pd.DataFrame({'sro':SRO_ptni, 'activity':Activity_ptni})
average_data_ptni = data_ptni.groupby('sro')['activity'].agg(['mean']).reset_index()

SRO_ptni3 = np.loadtxt('PtNi3/sro.csv',delimiter=',')
Activity_ptni3 = np.loadtxt('PtNi3/current.csv',delimiter=',')
Activity_ptni3 = [ (i/current_pt)  for i in Activity_ptni3]
data_ptni3 = pd.DataFrame({'sro':SRO_ptni3, 'activity':Activity_ptni3})
average_data_ptni3 = data_ptni3.groupby('sro')['activity'].agg(['mean']).reset_index()

fig, axes = plt.subplots(3, 1, figsize=(4, 7), sharex=True)  # 创建 1 列 3 行的子图

for ax in axes:
    # 设置刻度线朝内
    ax.tick_params(which='both', direction='in', top=False, right=False)
    ax.tick_params(direction='in', labelsize=12, which='major', length=6)

# 第一条曲线
axes[0].plot(average_data_pt3ni['sro'].to_numpy(), average_data_pt3ni['mean'].to_numpy(), 
             marker='o', markersize=9, markerfacecolor='w', markeredgecolor='#2ca02c', color='#2ca02c')
axes[0].set_yscale('log')
axes[0].set_ylim([1e-40, 1e10])
axes[0].legend([r'$\rm Pt_3Ni$'],loc=3, frameon=False,fontsize=12)
axes[0].set_yticks([1e-40, 1e-30, 1e-20, 1e-10, 1, 1e10])


# 第二条曲线
axes[1].plot(average_data_ptni['sro'].to_numpy(), average_data_ptni['mean'].to_numpy(), 
             marker='s', markersize=8, markerfacecolor='w', markeredgecolor='#2ca02c', color='#2ca02c')
axes[1].set_yscale('log')
axes[1].set_ylim([1e-40, 1e10])
axes[1].set_yticks([1e-40, 1e-30, 1e-20, 1e-10, 1, 1e10])
axes[1].legend([r'$\rm PtNi$'],loc=3, frameon=False,fontsize=12)


# 第三条曲线
axes[2].plot(average_data_ptni3['sro'].to_numpy(), average_data_ptni3['mean'].to_numpy(), 
             marker='p', markersize=10, markerfacecolor='w', markeredgecolor='#2ca02c', color='#2ca02c')
axes[2].set_yscale('log')
axes[2].set_ylim([1e-40, 1e10])
axes[2].set_yticks([1e-40, 1e-30, 1e-20, 1e-10, 1, 1e10])
axes[2].set_xlabel(r'$\rm \alpha^{Pt-Ni}$', fontsize=14)
axes[2].legend([r'$\rm PtNi_3$'],loc=3, frameon=False,fontsize=12)

# 调整布局并保存图像
# 调整子图间距，hspace=0 使子图之间没有间距
plt.subplots_adjust(hspace=0.1)
plt.savefig('sro_mean_current_pt3ni_ptni_ptni3_relative_pt.eps',bbox_inches='tight')
# 显示图形
plt.show()