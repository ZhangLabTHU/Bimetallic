from ase.io import read,write
import ase.db
import random
from ase import Atoms,Atom
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

SRO = np.loadtxt('Pt3Au/sro.csv',delimiter=',')
Activity = np.loadtxt('Pt3Au/current.csv',delimiter=',')
log_current_pt =  0.6*(1.37+0.23)-1.376
kT = 0.025852
current_pt = pow(10, log_current_pt/kT)

Activity = [np.log10( (i/current_pt) ) for i in Activity]
data = pd.DataFrame({'sro':SRO, 'activity':Activity})
average_data_pt3ag = data.groupby('sro')['activity'].agg(['max']).reset_index()

fig, ax = plt.subplots(figsize=(4.5,4))
# 设置刻度线朝内
ax.tick_params(which='both', direction='in', top=False, right=False)
# 设置次刻度线的样式
ax.tick_params(direction='in',labelsize=12, which='major', length=6,)  # 你可以调整颜色和长度
plt.plot(average_data_pt3ag['sro'].to_numpy(), average_data_pt3ag['max'].to_numpy(), 
             marker='o',markersize=12,markerfacecolor='w',markeredgecolor='#ff7f0e',color='#ff7f0e')
ax.set_ylim([-16,6])
# ax.set_xlim([-0.44,0.77])
# ax.set_xticks([-0.33,-0.11,0.11,0.33,0.55,0.77])
ax.set_yticks([-15, -10, -5, 0, 5])

ax.set_xlabel(r'$\rm \alpha^{Pt-Au}$',fontsize=14)
ax.set_ylabel('Max ORR activity',fontsize=14)
plt.savefig('sro_max_current_ptau_relative_pt.eps',bbox_inches='tight')
# 显示图形
plt.show()