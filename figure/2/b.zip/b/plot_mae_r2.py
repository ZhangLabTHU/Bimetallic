import matplotlib.pyplot as plt
import numpy as np

Gene = [0,1,2,3,4,5,6]
MAE_train = [0.038,0.057,0.060, 0.053, 0.048, 0.048, 0.046,]
MAE_test =  [0.110,0.079,0.070, 0.073, 0.067, 0.060, 0.056]
R2_train =  [0.98, 0.99, 0.99, 0.99, 0.98, 0.99, 0.98]
R2_test =   [0.73, 0.98, 0.97, 0.97, 0.96, 0.97, 0.97]

Colors = ['#264653','#2A9D8F','#E9C46A','#F4A261','#E76F51','#E63946']
fig,ax1=plt.subplots(figsize=(5,4))
ax1.plot(Gene, MAE_train,linestyle='-',color=Colors[0],marker='o',markersize=10)
ax1.plot(Gene, MAE_test,linestyle='--',color=Colors[0],marker='o',markersize=10)
ax1.set_xlabel('Cycles',fontsize=16)
ax1.set_ylabel('MAE (eV)',fontsize=16)
ax1.tick_params(direction='in',labelsize=14,which='major', length=6,)
ax1.set_ylim([0.02,0.18])
ax1.set_yticks([0.02,0.06,0.10,0.14,0.18])
ax1.legend(['MAE train', 'MAE test'],frameon=False,fontsize=14,loc=(0.55, 0.3))

ax2 = ax1.twinx()
ax2.plot(Gene, R2_train,linestyle='-',color=Colors[-1],marker='o',markersize=10)
ax2.plot(Gene, R2_test,linestyle='--',color=Colors[-1],marker='o',markersize=10)
ax2.set_ylabel(r'$\rm R^2$',fontsize=16)
ax2.tick_params(direction='in',labelsize=14,which='major', length=6,)
ax2.set_ylim([0.45,1.05])
ax2.legend([r'$\rm R^2 \ train$', r'$\rm R^2\ test$'],frameon=False,fontsize=14,loc=(0.60, 0.6))

plt.savefig('MAE_R2.eps',bbox_inches='tight')
plt.show()
